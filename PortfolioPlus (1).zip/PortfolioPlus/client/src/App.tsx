import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import ChronicleGriezmann from "@/pages/ChronicleGriezmann";
import ChronicleFinDeVie from "@/pages/ChronicleFinDeVie";
import ChronicleOleron from "@/pages/ChronicleOleron";
import ChronicleBudget from "@/pages/ChronicleBudget";
import AllChronicles from "@/pages/AllChronicles";
import ChronicleColereTiede from "@/pages/ChronicleColereTiede";
import ChronicleOtages from "@/pages/ChronicleOtages";
import ChronicleSportService from "@/pages/ChronicleSportService";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/chronicles" component={AllChronicles} />
      <Route path="/chroniques/griezmann" component={ChronicleGriezmann} />
      <Route path="/chroniques/fin-de-vie" component={ChronicleFinDeVie} />
      <Route path="/chroniques/oleron" component={ChronicleOleron} />
      <Route path="/chroniques/budget" component={ChronicleBudget} />
      <Route path="/chroniques/colere-tiede" component={ChronicleColereTiede} />
      <Route path="/chroniques/otages" component={ChronicleOtages} />
      <Route path="/chroniques/sport-service" component={ChronicleSportService} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
