import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChronicleColereTiede() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/chronicles">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Toutes les chroniques
            </Button>
          </Link>
          <div className="font-serif font-semibold text-lg">Julien Laurenceau Porte</div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-3xl">
        <article className="prose prose-lg prose-slate mx-auto">
          <div className="mb-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Société / Terrain
            </span>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight">
              La Colère Tiède
            </h1>
            <div className="text-muted-foreground italic">
              Bayonne, automne 2025
            </div>
          </div>

          <div className="space-y-6 text-gray-700 leading-relaxed">
            <p className="font-medium text-xl text-gray-900">
              Bayonne. Un matin d’automne.
            </p>

            <p>
              Le ciel hésite entre la pluie et l’attente. Sur le bitume un peu gris, trois cents silhouettes avancent lentement. Trois cents retraités, têtes nues ou bérets bien vissés, épaules solides malgré les ans. Trois cents, c’est peu. Tragiquement peu.
            </p>

            <p>
              Et pourtant… assez pour écrire une ligne d’histoire. Assez pour dire que quelque chose gronde, même si cela ne tonne pas. Une colère basse. Une colère qui ne claque pas, mais qui couve. Une colère tiède — et c’est peut-être ce qu’il y a de plus dangereux.
            </p>

            <p>
              Ils défilent, pancartes en main, dignes, calmes, mais déterminés. Ils ne hurlent pas. Ils marchent. Et dans leurs pas, ce pays entier qu’ils ont construit à la force des poignets et des illusions. Ils ne quémandent pas. Ils rappellent. Ils exigent.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Mémoire vive d’une nation oublieuse</h3>

            <p>
              Le drame, c’est que la France les regarde à peine. Elle a appris à les ignorer. À réduire leur vie en chiffres, leurs colères en notes de bas de page. Ils coûtent cher, dit-on dans les couloirs ministériels. Ils devraient “être raisonnables”, murmure-t-on dans les studios télévisés.
            </p>

            <p>
              Mais comment être raisonnable quand le frigo se vide plus vite que la pension ne tombe ? Quand la santé devient un privilège et que l’énergie se paie à prix fort ? Comment rester calme quand on demande à ceux qui ont donné toute leur vie… de donner encore un peu ?
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">L’arithmétique de l’ingratitude</h3>

            <p>
              Trois cents. C’est une goutte. Mais une goutte qui parle. Ils sont là, eux, et derrière eux, des millions. Des millions qui ne croient plus aux manifestations polies, aux mots doux, aux promesses creuses. Chaque banderole dit la même chose qu’il y a dix ans. Et chaque ministre répond avec les mêmes phrases vides.
            </p>

            <p>
              C’est cela, peut-être, le plus grand échec : que la colère se soit habituée à elle-même. Qu’elle ait appris à défiler dans les clous, à signer le registre, à sourire pour la photo du journal local. L’État adore ces colères-là. Inoffensives. Classées. Étouffées.
            </p>

            <p>
              Mais dans les interstices de cette colère sage, quelque chose vibre. Une menace douce. Et si, demain, ces retraités ne défilaient plus pour réclamer, mais pour imposer ? Et si cette marche devenait une levée ? Alors peut-être que la République se rappellerait qu’elle leur doit tout.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Dernier sursaut d’un premier rang</h3>

            <p>
              La génération qui bat le pavé a connu le plein emploi, les services publics solides, les promesses républicaines. Elle a bâti les écoles, les routes, les hôpitaux. Et aujourd’hui, on l’invite à “faire un effort”. Mais elle a déjà tout donné.
            </p>

            <p>
              Ce jeudi à Bayonne, le Pays basque n’a pas rugi. Il a toussé. Mais cette toux pourrait devenir une voix. Et cette voix, une clameur.
            </p>

            <p>
              Peut-être qu’un jour, les retraités cesseront de vouloir “se faire entendre”. Peut-être qu’ils se lèveront pour exiger des comptes. Non pas pour eux seuls — mais pour ce que leur oubli dit de nous tous.
            </p>

            <p>
              Parce qu’un pays qui néglige sa mémoire, finit toujours par perdre son avenir.
            </p>

            <div className="pt-8 mt-12 border-t border-gray-200 text-center font-serif text-lg">
              JLP
            </div>
          </div>
        </article>
      </main>

      <footer className="bg-gray-50 py-12 border-t">
        <div className="container mx-auto px-4 text-center">
          <h3 className="font-serif text-2xl mb-6">Vous appréciez cette plume ?</h3>
          <div className="flex justify-center gap-4">
            <Link href="/chronicles">
              <Button variant="outline">Lire d'autres chroniques</Button>
            </Link>
            <a href="mailto:julien_laurenceau@hotmail.com">
              <Button>Me contacter</Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
