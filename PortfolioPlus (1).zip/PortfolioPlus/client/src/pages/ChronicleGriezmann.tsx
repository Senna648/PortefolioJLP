import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChronicleGriezmann() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Retour au portfolio
            </Button>
          </Link>
          <div className="font-serif font-semibold text-lg">Julien Laurenceau Porte</div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-3xl">
        <article className="prose prose-lg prose-slate mx-auto">
          <div className="mb-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Justice / Société
            </span>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight">
              Griezmann, l’ombre d’un mentor accusé
            </h1>
            <div className="text-muted-foreground italic">
              Bayonne, novembre 2025
            </div>
          </div>

          <div className="space-y-6 text-gray-700 leading-relaxed">
            <p className="font-medium text-xl text-gray-900">
              Bayonne, novembre gris.
            </p>

            <p>
              Un silence dense, presque compact, règne sur les abords du tribunal correctionnel. Les regards se croisent sans oser se fixer, comme lestés d’un poids ancien. Ce mardi matin, dans le froid discret du Pays basque, s’ouvre un procès qui remue bien au-delà des bancs de la justice : celui d’Éric Olhats, 62 ans, silhouette autrefois familière des terrains de football, mentor reconnu, éclaireur de talents, formateur révéré.
            </p>

            <p>
              Aujourd’hui, l’homme comparaît non plus pour ses choix tactiques, mais pour des accusations autrement plus sombres : des atteintes sexuelles présumées sur plusieurs mineurs, entre la fin des années 1990 et le début des années 2000. Des faits graves, niés en bloc par l’intéressé, qui se dresse devant ses juges avec cette raideur qu’on devine forgée dans l’attente, après deux longues années de détention provisoire au centre pénitentiaire de Mont-de-Marsan.
            </p>

            <p className="font-bold">Un souffle suspendu dans la salle.</p>

            <p>
              Dans les travées de l’audience, certains plaignants sont là, devenus adultes depuis, présents sans éclat, mais entiers, comme pour faire face, enfin. L’atmosphère est lourde, et chaque mot prononcé semble retentir un peu plus fort que de raison. Ce procès, attendu, redouté, longtemps ajourné, est aussi celui d’une époque où la frontière entre autorité éducative et abus de pouvoir restait floue, tue, parfois ignorée.
            </p>

            <p className="font-bold">La ligne de défense est claire.</p>

            <p>
              « Aucun geste déplacé. Aucun fait prouvé. Rien que des souvenirs distordus par le temps. » La voix des avocats d’Olhats tranche. Ils évoquent des accusations fragiles, construites sur des réminiscences « floues », « non corroborées ». Ils parlent de ce lien pédagogique, de cette confiance inhérente à l’encadrement sportif, que l’on risque aujourd’hui de déformer. L’homme, lui, reste droit, presque figé dans le silence, n’opposant à l'accusation que la constance de ses dénégations.
            </p>

            <p className="font-bold">Mais les voix s’élèvent.</p>

            <p>
              Du côté des plaignants, les récits affluent. Tous ne concordent pas. Certains vacillent, hésitent, reviennent sur leurs pas. Mais d’autres tracent une ligne droite, glaçante. Des gestes évoqués. Des regards insistants. Des tensions sourdes durant les entraînements, dans les vestiaires, lors de déplacements. Des impressions d’enfance qui, mises bout à bout, tissent une trame que l’accusation juge « troublante », persistante.
            </p>

            <p className="font-bold">Et le monde du football vacille.</p>

            <p>
              Car derrière le nom d’Éric Olhats, c’est tout un pan du football amateur français qui tremble. Celui d’un homme qui fut longtemps recruteur à la Real Sociedad. Celui qui, dit-on, crut le premier au potentiel d’un jeune Griezmann, frêle gamin rejeté par les centres de formation. Celui que l’on croisait sur les pelouses du Sud-Ouest, avec la passion comme unique boussole.
            </p>

            <p>
              Aujourd’hui, c’est ce visage-là qui se retrouve dans la lumière crue de la justice. Et chacun, dans la salle comme à l’extérieur, s’interroge : sur la mémoire, sur le silence des années, sur ce qui fut vu ou ignoré.
            </p>

            <p>
              Le procès doit se poursuivre toute la semaine. Les plaidoiries sont attendues dans les prochains jours, tout comme le verdict. Mais déjà, l’essentiel s’est peut-être joué ailleurs : dans la force de ceux qui ont parlé. Et dans la chute lente d’un homme que l’on croyait au-dessus de tout soupçon.
            </p>

            <div className="pt-8 mt-12 border-t border-gray-200 text-center font-serif text-lg">
              JLP
            </div>
          </div>
        </article>
      </main>

      <footer className="bg-gray-50 py-12 border-t">
        <div className="container mx-auto px-4 text-center">
          <h3 className="font-serif text-2xl mb-6">Vous appréciez cette plume ?</h3>
          <div className="flex justify-center gap-4">
            <Link href="/">
              <Button variant="outline">Lire d'autres chroniques</Button>
            </Link>
            <a href="mailto:julien_laurenceau@hotmail.com">
              <Button>Me contacter</Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
