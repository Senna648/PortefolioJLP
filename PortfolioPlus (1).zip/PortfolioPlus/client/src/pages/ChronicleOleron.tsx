import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChronicleOleron() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Retour au portfolio
            </Button>
          </Link>
          <div className="font-serif font-semibold text-lg">Julien Laurenceau Porte</div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-3xl">
        <article className="prose prose-lg prose-slate mx-auto">
          <div className="mb-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Société / Faits Divers
            </span>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight">
              Île d’Oléron : la violence des invisibles
            </h1>
            <div className="text-muted-foreground italic">
              Novembre 2025
            </div>
          </div>

          <div className="space-y-6 text-gray-700 leading-relaxed">
            <p className="font-medium text-xl text-gray-900">
              Un mercredi de novembre sur l’île d’Oléron, le calme a cédé place à l’absurde. Trente-cinq minutes durant, un homme de trente-cinq ans, seul, au volant de sa voiture, a volontairement percuté cinq personnes. Deux sont grièvement blessées.
            </p>

            <p>
              Les faits se sont déroulés entre Dolus et Saint-Pierre-d’Oléron, sur ces routes que l’on imagine réservées aux vélos tranquilles, aux passants sans hâte. Ce jour-là, elles sont devenues le théâtre d’un effondrement.
            </p>

            <p>
              Au moment de son interpellation, le conducteur a crié « Allahou Akbar ». Pourtant, il n’était connu d’aucun service de renseignement, n’apparaissait dans aucune base de données, n’était suivi par aucun organisme antiterroriste. Le parquet national antiterroriste ne s’est pas saisi. L’homme vivait seul, dans un mobil-home. Il était connu localement pour ses problèmes d’addiction, alcool et drogue. Un homme à la dérive, mais que personne ne semblait craindre, ni suivre.
            </p>

            <p>
              À première vue, cela ressemble à un acte de démence. Mais s’agit-il d’une pathologie individuelle, d’un pur dérèglement psychiatrique ? Ou plutôt d’un faisceau de causes entremêlées, d’une somme silencieuse : isolement social, usage chronique de substances, précarité existentielle, fragilité psychique non prise en charge ? Rien ne permet de trancher. Tout oblige à penser plus largement.
            </p>

            <p>
              L’isolement est une matrice. Il désorganise les repères, amplifie les fissures. L’addiction, loin d’être un simple symptôme, agit comme un accélérateur chimique. Elle modifie les émotions, fragilise la cognition, dérègle l’impulsion. Le passage à l’acte, dans ce contexte, devient possible. Une violence dirigée, brutale, sans cause identifiée, mais avec un effet dévastateur.
            </p>

            <p>
              Ce geste n’est pas un attentat au sens classique. Ce n’est pas non plus un accident. C’est une fracture. L’expression visible d’un mal invisible. Il dit l’absence de filet, l’effondrement silencieux, la solitude radicale. Il montre que l’extrême violence ne naît pas toujours d’un projet, mais parfois d’une chute. Et que cette chute ne vient pas de nulle part.
            </p>

            <p>
              Ce drame n’est pas une anomalie. Il est un avertissement. Il dit ce que deviennent les invisibles quand plus rien ne les relie aux autres. Il dit que l’irréparable commence souvent bien avant le geste lui-même. Il commence dans les angles morts.
            </p>

            <div className="pt-8 mt-12 border-t border-gray-200 text-center font-serif text-lg">
              JLP
            </div>
          </div>
        </article>
      </main>

      <footer className="bg-gray-50 py-12 border-t">
        <div className="container mx-auto px-4 text-center">
          <h3 className="font-serif text-2xl mb-6">Vous appréciez cette plume ?</h3>
          <div className="flex justify-center gap-4">
            <Link href="/">
              <Button variant="outline">Lire d'autres chroniques</Button>
            </Link>
            <a href="mailto:julien_laurenceau@hotmail.com">
              <Button>Me contacter</Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
