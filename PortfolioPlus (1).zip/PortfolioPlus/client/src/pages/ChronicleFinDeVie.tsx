import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChronicleFinDeVie() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Retour au portfolio
            </Button>
          </Link>
          <div className="font-serif font-semibold text-lg">Julien Laurenceau Porte</div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-3xl">
        <article className="prose prose-lg prose-slate mx-auto">
          <div className="mb-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Société / Éthique
            </span>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight">
              Fin de vie : un pays à la croisée de ses consciences
            </h1>
          </div>

          <div className="space-y-6 text-gray-700 leading-relaxed">
            <p className="font-medium text-xl text-gray-900">
              Il y a des débats que l’on croit éternels tant ils avancent à pas lents, pesants, souvent douloureux. Celui sur la fin de vie est de ceux-là. Ce mois-ci, le Sénat s’apprête à rouvrir la discussion. Non plus seulement sur les bornes de l’acharnement thérapeutique, mais sur une bascule inédite : celle d’un droit à mourir accompagné.
            </p>

            <p>
              Le mot heurte, trouble, puis s’installe : “aide à mourir”. Comme une promesse qu’en bout de course, une main tiendra la vôtre — sans fuite, sans violence, sans clandestinité. Est-ce un progrès ou une pente glissante ? Le débat est lancé. Il divise, inquiète, mais surtout… il revient. Ce seul fait dit quelque chose : la société a changé.
            </p>

            <p>
              L’autonomie des patients en fin de vie n’est plus un tabou. Et face aux défis d’une médecine qui prolonge parfois plus la vie que la dignité, la question n’est plus “faut-il en parler ?”, mais “jusqu’où peut-on aller ?”.
            </p>

            <p>
              Un sceptique, prudent, répliquerait : “On en parle depuis vingt ans… et pourtant.” Il aurait raison : les textes naissent, s’éteignent, et la machine parlementaire demeure incertaine. Mais quelque chose, cette fois, semble enclenché. Lentement, certes. Mais en mouvement.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Les sacrifiés du silence</h3>

            <p>
              Pour comprendre la force de ce moment, il faut nommer les visages du passé. Deux histoires. Deux corps. Deux tragédies.
            </p>

            <p>
              Nicolas Bonnemaison, médecin urgentiste, condamné en 2015 pour avoir voulu abréger les souffrances d’une patiente en phase terminale. Radié. Abandonné. Puni pour avoir agi là où la loi se taisait.
            </p>

            <p>
              Chantal Sébire, elle, n’était pas médecin. Elle était mère, souffrante, condamnée par une tumeur défigurante et incurable. Elle a demandé, supplié même, à mourir dans la légalité. La justice a dit non. Alors elle est morte seule, en secret.
            </p>

            <p>
              Ces noms ne sont pas des anecdotes judiciaires. Ce sont des épouvantails éthiques que la République traîne derrière elle. Les uns comme les autres ont été piégés par un vide législatif : ni autorisation, ni accompagnement, seulement la culpabilité de choisir.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Un virage timide, mais réel</h3>

            <p>
              Aujourd’hui, le débat a changé de nature. Il ne s’agit plus seulement de dire “oui ou non à l’euthanasie”, mais de penser une loi d’accompagnement. Une loi qui réunisse : soins palliatifs renforcés, accompagnement des familles, encadrement médical, critères clairs — et surtout, dignité.
            </p>

            <p>
              Ce n’est pas rien. Cela signifie que l’on reconnaît enfin que les soins palliatifs, aussi indispensables soient-ils, ne suffisent pas toujours.
            </p>

            <p>
              Mais prudence. Tout est dans les détails. Qui pourra demander cette aide ? Sur quels critères ? Qui décidera ? Et comment garantir qu’il ne s’agira pas d’une solution de facilité quand l’accompagnement coûte cher et demande du temps ?
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Ce que je retiens, ce que je redoute</h3>

            <p>
              Alors oui, un tournant semble amorcé. Une société plus mature, plus lucide, cherche à poser les mots justes sur l’ultime passage. Oui, les erreurs d’hier, comme celles vécues par Bonnemaison ou Sébire, plaident pour une loi claire, humaine, et assumée.
            </p>

            <p>
              Mais non, tout n’est pas gagné. Il reste à écrire le cadre, à fixer les garanties, à préserver les plus fragiles. Rien n’est simple, rien ne doit l’être.
            </p>

            <div className="pt-8 mt-12 border-t border-gray-200 text-center font-serif text-lg">
              JLP
            </div>
          </div>
        </article>
      </main>

      <footer className="bg-gray-50 py-12 border-t">
        <div className="container mx-auto px-4 text-center">
          <h3 className="font-serif text-2xl mb-6">Vous appréciez cette plume ?</h3>
          <div className="flex justify-center gap-4">
            <Link href="/">
              <Button variant="outline">Lire d'autres chroniques</Button>
            </Link>
            <a href="mailto:julien_laurenceau@hotmail.com">
              <Button>Me contacter</Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
