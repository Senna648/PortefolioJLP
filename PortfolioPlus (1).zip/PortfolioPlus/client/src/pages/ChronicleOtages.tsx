import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChronicleOtages() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/chronicles">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Toutes les chroniques
            </Button>
          </Link>
          <div className="font-serif font-semibold text-lg">Julien Laurenceau Porte</div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-3xl">
        <article className="prose prose-lg prose-slate mx-auto">
          <div className="mb-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              International / Diplomatie
            </span>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight">
              Les otages revenus du silence
            </h1>
            <div className="text-muted-foreground italic">
              Bayonne, novembre 2025
            </div>
          </div>

          <div className="space-y-6 text-gray-700 leading-relaxed">
            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Le souffle du retour</h3>
            <p>
              Quand leurs pieds ont touché le sol de Villacoublay, un frisson a traversé l’assemblée. Pas de cris. Pas de larmes en cascade. Un silence seulement — lourd, contenu — comme un souffle enfin repris après trois ans et demi d’apnée.
            </p>

            <p>
              Cécile Kohler et Jacques Paris sont rentrés. Ils étaient partis en touristes. Ils reviennent en symboles. Symboles d’un courage sans emphase, d’une résistance murmurée dans l’ombre d’une cellule, et d’une diplomatie obstinée.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Evin, l’envers du monde</h3>

            <p>
              Evin. Un nom qui claque comme un couperet. Cette prison nichée au pied des montagnes de Téhéran n’a rien d’un centre de détention ordinaire. C’est un théâtre invisible, une fabrique de silence où l’Occident est convoqué en huis clos. Là, les accusations sont aussi floues que les peines sont longues : espionnage, atteinte à la sécurité nationale — des prétextes, souvent, pour justifier l’arbitraire.
            </p>

            <p>
              Dans cet enfer de béton et de néons blafards, Kohler et Paris ont tenu. « Sans le soutien venu de France, nous n’aurions pas tenu. » Ils le disent simplement, sans éclat. Mais derrière ces mots affleure l’essentiel : la détention politique n’est pas seulement une punition, c’est une tentative d’effacement.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">La lumière des autres</h3>

            <p>
              Pendant ce temps, en France, d’autres veillaient. Une poignée de proches, de soutiens, de silhouettes obstinées qui, jour après jour, ont maintenu la flamme. Des banderoles, des lettres, des silences partagés devant les ministères. Peu de bruit, mais une présence — constante, infatigable.
            </p>

            <p>
              Le sceptique demandera : que peut une lettre contre une porte verrouillée ? Tout. Car dans la mécanique mentale de l’enfermement, savoir qu’on existe encore quelque part suffit parfois à tenir debout. C’est ce fil ténu, tendu entre deux continents, qui a empêché la chute.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Le dessous des négociations</h3>

            <p>
              Rien de tout cela ne s’est joué à ciel ouvert. Dans les coulisses du Quai d’Orsay, la cellule de crise a manœuvré dans l’ombre. Via Oman, via le Qatar, des canaux discrets ont été ouverts. Les discussions, longues, laborieuses, ont mêlé nucléaire, commerce, et otages. L’Iran a joué sa carte : la diplomatie des otages. Une stratégie cynique, méthodique, implacable.
            </p>

            <p>
              La France, elle, a gardé le silence. Pas par faiblesse, mais par nécessité. Dans ces affaires, la parole publique est une monnaie trop bruyante. C’est dans le non-dit que se jouent les issues.
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Après le retour, l’épreuve du réel</h3>

            <p>
              Mais revenir, ce n’est pas rentrer. C’est réapprendre à marcher dans le bruit. À dormir sans redouter la porte. À respirer sans sursauter.
            </p>

            <p>
              Pour Kohler et Paris, la liberté n’est pas encore un état : c’est une reconquête. Chaque rayon de lumière, chaque visage, chaque parole spontanée devra être réapprivoisé. Et cette lente remontée vers la vie nous interroge, nous aussi : que reste-t-il de notre solidarité, une fois les banderoles pliées ?
            </p>

            <h3 className="font-bold text-2xl mt-8 mb-4 font-serif">Un avertissement dans la clarté</h3>

            <p>
              Leur libération n’est pas une victoire. C’est une parenthèse. Un sursis dans une guerre feutrée où les citoyens deviennent monnaies d’échange, et la dignité humaine, une variable diplomatique.
            </p>

            <p>
              Mais au cœur de cette mécanique froide, une certitude subsiste : deux êtres ont été arrachés à l’oubli par la persévérance d’autres êtres. Et dans un monde cynique, cela suffit à faire miracle.
            </p>

            <div className="pt-8 mt-12 border-t border-gray-200 text-center font-serif text-lg">
              JLP
            </div>
          </div>
        </article>
      </main>

      <footer className="bg-gray-50 py-12 border-t">
        <div className="container mx-auto px-4 text-center">
          <h3 className="font-serif text-2xl mb-6">Vous appréciez cette plume ?</h3>
          <div className="flex justify-center gap-4">
            <Link href="/chronicles">
              <Button variant="outline">Lire d'autres chroniques</Button>
            </Link>
            <a href="mailto:julien_laurenceau@hotmail.com">
              <Button>Me contacter</Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
