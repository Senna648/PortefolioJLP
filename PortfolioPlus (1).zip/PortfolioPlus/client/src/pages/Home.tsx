import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Users, 
  Scale, 
  Globe, 
  Users2, 
  Trophy, 
  Bot, 
  PenTool, 
  FileText, 
  BarChart3, 
  Edit3, 
  MessageSquare, 
  FileCheck, 
  Download, 
  ArrowRight, 
  BookOpen,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  ChevronRight,
  FileDown
} from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen bg-white font-sans text-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md shadow-sm">
        <div className="container mx-auto flex h-20 items-center justify-between px-4">
          <div className="flex items-center gap-2">
             <img src="/logo.png" alt="Logo JLP" className="h-12 w-auto object-contain" />
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <a href="#about" className="hover:text-primary transition-colors">À propos</a>
            <a href="#expertises" className="hover:text-primary transition-colors">Expertises</a>
            <a href="#services" className="hover:text-primary transition-colors">Services</a>
            <a href="#chronicles" className="hover:text-primary transition-colors">Chroniques</a>
            <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
          </nav>
          <a href="#contact">
            <Button size="sm">Me contacter</Button>
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 md:py-28 px-4 text-center bg-slate-50 relative overflow-hidden">
        <div className="container mx-auto max-w-4xl relative z-10">
          <div className="mb-6 flex justify-center text-sm text-slate-500 items-center gap-2 font-medium tracking-wide uppercase">
            <MapPin className="h-4 w-4" /> Bayonne, France / Télétravail
          </div>
          
          <h1 className="mb-4 font-serif text-5xl md:text-7xl font-bold tracking-tight text-slate-900 leading-tight">
            Julien Laurenceau Porte
          </h1>
          
          {/* Logo under name */}
          <div className="flex justify-center mb-8">
            <img src="/logo.png" alt="Logo JLP" className="h-24 md:h-32 w-auto opacity-90" />
          </div>

          <p className="mb-10 text-xl md:text-3xl font-serif text-slate-700">
            Rédacteur IA <span className="mx-2 text-slate-300">•</span> Chroniques & analyses
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 flex-wrap">
            <a href="#contact">
              <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base">Réserver un appel</Button>
            </a>
            <Link href="/chronicles">
              <Button size="lg" variant="outline" className="w-full sm:w-auto h-12 px-8 text-base bg-white border-slate-300">
                Lire toutes mes chroniques
              </Button>
            </Link>
            <a href="/cv_julien_laurenceau.pdf" download target="_blank">
              <Button size="lg" variant="secondary" className="w-full sm:w-auto h-12 px-8 text-base gap-2">
                <Download className="h-4 w-4" />
                CV PDF
              </Button>
            </a>
            <a href="/portfolio_redactionnel.pdf" download target="_blank">
              <Button size="lg" variant="secondary" className="w-full sm:w-auto h-12 px-8 text-base gap-2 bg-slate-200 hover:bg-slate-300 text-slate-800">
                <FileDown className="h-4 w-4" />
                Portfolio PDF
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-20 px-4 container mx-auto max-w-4xl">
        <div className="flex items-center justify-center gap-4 mb-12">
          <img src="/logo.png" alt="Logo JLP" className="h-12 w-auto" />
          <h2 className="font-serif text-4xl font-bold">À propos</h2>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {['Chroniques sociales', 'Justice & affaires sensibles', 'International & géopolitique', 'Analyse data'].map((tag) => (
            <span key={tag} className="px-4 py-1.5 bg-slate-100 text-slate-700 text-sm rounded-full font-semibold tracking-wide">
              {tag}
            </span>
          ))}
        </div>
        
        <div className="prose prose-lg mx-auto text-slate-600 text-center leading-relaxed">
          <p className="mb-8 text-xl font-medium text-slate-800">
            Je suis un rédacteur numérique spécialisé en chroniques sociales, justice, international et sport. 
            Ma plume associe narration, rigueur et observation du terrain.
          </p>
          <p className="mb-6">
            J'allie la clarté des mots à la rigueur des faits. Mon style : une plume engagée, narrative, rigoureuse. Je rends lisible les faits complexes du réel. 
            Résultat : plus de fluidité, d'arguments qualifiés, et une transformation heureuse du lectorat en audience attentive et augmentée.
          </p>
          <p>
            Formé au journalisme, à l'écriture professionnelle et à l'analyse de données (Certifications Google, Michigan, Illinois, Colorado, DeepLearning.AI), j'utilise l'IA comme un outil de structuration, de veille et de vérification, jamais comme une béquille.
          </p>
        </div>

        {/* Why work with me - Watermark effect */}
        <div className="mt-20 relative bg-primary/5 rounded-3xl p-10 md:p-16 overflow-hidden">
          {/* Watermark Logo */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 pointer-events-none opacity-5 z-0">
             <img src="/logo.png" alt="" className="w-full h-full object-contain grayscale" />
          </div>
          
          <div className="relative z-10">
            <h3 className="font-serif text-2xl font-bold mb-10 text-center">Pourquoi travailler avec moi ?</h3>
            <div className="grid md:grid-cols-3 gap-10">
              <div className="text-center">
                <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md text-primary">
                  <PenTool className="h-7 w-7" />
                </div>
                <h4 className="font-bold text-lg mb-3">Plume narrative + analyse rigoureuse</h4>
                <p className="text-slate-600">Je ne me contente pas d'écrire, je raconte et j'analyse pour donner du sens.</p>
              </div>
              <div className="text-center">
                <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md text-primary">
                  <FileCheck className="h-7 w-7" />
                </div>
                <h4 className="font-bold text-lg mb-3">Travail rapide et fiable</h4>
                <p className="text-slate-600">Respect des délais et livrables soignés, prêts à publier.</p>
              </div>
              <div className="text-center">
                <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md text-primary">
                  <Users className="h-7 w-7" />
                </div>
                <h4 className="font-bold text-lg mb-3">Expertise terrain</h4>
                <p className="text-slate-600">Une expérience concrète (hôpital, sport, service public) qui nourrit mes écrits.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Expertises */}
      <section id="expertises" className="py-24 bg-slate-50 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold mb-4">Expertises</h2>
            <p className="text-slate-600 text-lg">Des domaines de spécialisation pour une couverture complète des enjeux contemporains</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ExpertiseCard 
              icon={<Users className="h-6 w-6 text-white" />}
              title="Chroniques sociales & politiques publiques"
              desc="Analyse des décisions politiques, impact social et travail documentaire."
            />
            <ExpertiseCard 
              icon={<Scale className="h-6 w-6 text-white" />}
              title="Justice & affaires sensibles"
              desc="Récits de procès, affaires complexes, enjeux de défense, silence et responsabilité."
            />
            <ExpertiseCard 
              icon={<Globe className="h-6 w-6 text-white" />}
              title="International & géopolitique"
              desc="Décryptage d'affaires internationales, diplomatie des otages, rapports de force discrets."
            />
            <ExpertiseCard 
              icon={<Users2 className="h-6 w-6 text-white" />}
              title="Société civile & terrain"
              desc="Manifestations, hôpital, service public : les bruits de fond souvent ignorés du terrain."
            />
            <ExpertiseCard 
              icon={<Trophy className="h-6 w-6 text-white" />}
              title="Sport & culture sportive"
              desc="Récits, gestion humaine, vie des clubs. Quand le sport raconte une société."
            />
            <ExpertiseCard 
              icon={<Bot className="h-6 w-6 text-white" />}
              title="Analyse assistée par IA"
              desc="Veille, structuration d'idées, recherche d'angle : précision et fact-checking par IA."
            />
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-24 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold mb-4">Services</h2>
            <p className="text-slate-600 text-lg">Une gamme complète de prestations rédactionnelles adaptées à vos besoins</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard 
              title="Chroniques d'articles de fond"
              items={["Sujets de 800 à 1500 mots traités dans le détail", "Angle incisif, documenté", "Apport de perspective et analyse"]}
            />
            <ServiceCard 
              title="Dossiers & séries"
              items={["Enquêtes thématiques sur plusieurs articles", "Narration feuilletonnante", "Mise en perspective historique et sociale"]}
            />
            <ServiceCard 
              title="Écriture augmentée par la data"
              items={["Renforcer le récit par des chiffres clairs", "Création de rapports synthétiques", "Visualisation simple et lisible"]}
            />
            <ServiceCard 
              title="Réécriture & structuration"
              items={["Transformer un brouillon en article publié", "Structuration logique et claire", "Vérification de l'orthographe et du ton"]}
            />
            <ServiceCard 
              title="Communication éditoriale"
              items={["Textes pour newsletters, réseaux sociaux", "Storytelling de marque", "Adaptation au ton de l'entreprise"]}
            />
            <ServiceCard 
              title="Tests rédactionnels"
              items={["Possibilité de réaliser un test court (400-500 mots)", "Délai ultra-rapide", "Sans engagement pour évaluer la collaboration"]}
            />
          </div>
        </div>
      </section>

      {/* Chronicles Selection */}
      <section id="chronicles" className="py-24 bg-slate-50 px-4 relative">
        {/* Banner with logo */}
        <div className="container mx-auto max-w-5xl mb-16">
          <div className="bg-slate-900 text-white rounded-xl p-8 flex flex-col md:flex-row items-center justify-between shadow-xl">
             <div className="flex items-center gap-6 mb-6 md:mb-0">
                <div className="bg-white/10 p-4 rounded-full backdrop-blur-sm">
                   <img src="/logo.png" alt="Logo JLP" className="h-12 w-auto invert brightness-0" />
                </div>
                <div>
                   <h2 className="font-serif text-2xl font-bold">Sélection de chroniques</h2>
                   <p className="text-slate-300">Signature JLP — Plume, analyse, impact.</p>
                </div>
             </div>
             <Link href="/chronicles">
                <Button variant="secondary" className="bg-white text-slate-900 hover:bg-slate-100">
                   Voir toutes les chroniques
                </Button>
             </Link>
          </div>
        </div>

        <div className="container mx-auto max-w-5xl" id="chronicles-grid">
          {/* Featured Chronicle */}
          <div className="bg-white rounded-2xl shadow-md overflow-hidden border border-slate-200 mb-12 transition-transform hover:-translate-y-1 duration-300">
            <div className="p-8 md:p-12 grid md:grid-cols-2 gap-10 items-center">
              <div>
                <span className="inline-block py-1 px-3 rounded-full bg-blue-100 text-blue-800 text-xs font-bold mb-4">
                  À LA UNE
                </span>
                <div className="text-sm text-slate-500 mb-2 font-medium uppercase tracking-wider">Justice / Société</div>
                <h3 className="font-serif text-3xl md:text-4xl font-bold mb-4 text-slate-900 leading-tight">
                  Griezmann, l’ombre d’un mentor accusé
                </h3>
                <div className="flex gap-2 mb-8">
                  {['Justice', 'Football', 'Défense'].map(tag => (
                    <span key={tag} className="text-xs bg-slate-100 px-3 py-1 rounded-full text-slate-600 font-medium">{tag}</span>
                  ))}
                </div>
                <Link href="/chroniques/griezmann">
                  <Button size="lg" className="w-full sm:w-auto">Lire la chronique complète</Button>
                </Link>
              </div>
              <div className="text-slate-600 italic leading-relaxed border-l-4 border-primary/20 pl-8 text-lg">
                "Bayonne, novembre gris. Un silence dense, presque compact, règne sur les abords du tribunal correctionnel. Les regards se croisent sans oser se fixer... L’affaire dépasse la seule figure de Griezmann : c’est tout un pan du football amateur qui tremble."
              </div>
            </div>
          </div>

          {/* Other Chronicles Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
             <ChronicleCard 
               href="/chroniques/fin-de-vie"
               category="Société / Éthique"
               title="Fin de vie : un pays à la croisée de ses consciences"
               excerpt="Il y a des débats que l’on croit éternels tant ils avancent à pas lents, pesants, souvent douloureux. Celui sur la fin de vie est de ceux-là. Ce mois-ci, le Sénat s’apprête à rouvrir la discussion."
               tags={['Société', 'Éthique', 'Politique']}
             />
             <ChronicleCard 
               href="/chroniques/budget"
               category="Politique / Économie"
               title="Quand « tenir les comptes » devient la faute de solidarité"
               excerpt="Pendant que les hôpitaux crèvent et que les soignants s’épuisent, le gouvernement taille dans la Sécu comme on taille une haie trop vivante. Priorité au chiffre, quitte à déchirer ce qu’il reste du tissu social."
               tags={['Budget', 'Santé', 'Politique']}
             />
             <ChronicleCard 
               href="/chroniques/oleron"
               category="Société / Faits divers"
               title="Île d’Oléron : la violence des invisibles"
               excerpt="Un mercredi de novembre sur l’île d’Oléron, le calme a cédé place à l’absurde. Trente-cinq minutes durant, un homme seul au volant de sa voiture a volontairement percuté cinq personnes."
               tags={['Société', 'Faits divers', 'Analyse']}
             />
          </div>
          
          <div className="flex justify-center">
            <Link href="/chronicles">
              <Button variant="outline" size="lg" className="gap-2 border-slate-300 bg-white px-8">
                Voir toutes les chroniques <ChevronRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Book Section */}
      <section className="py-24 bg-slate-900 text-white px-4 overflow-hidden relative">
         {/* Background pattern/gradient */}
         <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-slate-950 z-0"></div>
         
        <div className="container mx-auto max-w-5xl flex flex-col md:flex-row items-center gap-16 relative z-10">
          <div className="flex-1">
             <div className="flex items-center gap-4 mb-8">
               <span className="inline-block py-1.5 px-4 rounded-full bg-white/10 text-white text-xs font-bold border border-white/20 tracking-wider uppercase">
                  Long Format
               </span>
               <div className="flex items-center gap-2 bg-white text-slate-900 px-3 py-1 rounded-full text-xs font-bold">
                  <img src="/logo.png" alt="JLP" className="h-4 w-4" /> JLP – Auteur
               </div>
             </div>
             
             <h2 className="font-serif text-4xl md:text-6xl font-bold mb-6 leading-tight">
               Ayrton Senna <br/>
               <span className="text-slate-400 italic text-3xl md:text-5xl">La lumière éternelle</span>
             </h2>
             <p className="text-xl text-slate-300 mb-10 leading-relaxed max-w-xl">
               Une biographie documentaire qui explore la vie, la carrière et l'héritage spirituel de l'icône de la Formule 1. Plus qu'un pilote, un mythe dont la lumière continue de briller bien au-delà des circuits.
             </p>
             
             <div className="flex flex-col sm:flex-row gap-4 items-start">
               <a href="https://www.amazon.fr/Ayrton-Senna-Silva-lumi%C3%A8re-%C3%A9ternel-ebook/dp/B0D3B28QQM" target="_blank" rel="noreferrer">
                 <Button size="lg" className="bg-white text-slate-900 hover:bg-slate-100 border-none font-bold h-14 px-8">
                   <BookOpen className="mr-2 h-5 w-5" />
                   Commander sur Amazon
                 </Button>
               </a>
               <div className="flex items-center h-14 px-4 text-slate-400 text-sm">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                  Disponible en format Kindle
               </div>
             </div>
          </div>
          
          <div className="w-full md:w-[350px] aspect-[2/3] bg-gradient-to-br from-slate-700 to-slate-800 rounded-lg shadow-2xl flex items-center justify-center border border-white/10 relative group hover:scale-[1.02] transition-transform duration-500">
             <div className="absolute inset-0 bg-black/20 z-0"></div>
             {/* Placeholder for book cover */}
             <div className="text-center p-8 relative z-10">
               <img src="/logo.png" className="h-16 w-auto mx-auto mb-8 opacity-80 invert brightness-0" />
               <div className="font-serif text-3xl font-bold mb-2">Ayrton Senna</div>
               <div className="text-lg opacity-70 italic font-serif">La lumière éternelle</div>
               <div className="mt-12 text-xs opacity-50 uppercase tracking-[0.2em]">Biographie</div>
             </div>
          </div>
        </div>
      </section>

      {/* Sports Archives - Sud Ouest */}
      <section className="py-24 bg-white px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold mb-4">Archives sportives – Sud Ouest</h2>
            <p className="text-slate-600 text-lg">Sélection d'articles et reportages de presse illustrant mon ancrage dans le sport local et la course à pied.</p>
          </div>

          {/* Introduction text */}
          <div className="max-w-3xl mx-auto mb-16 text-center">
            <p className="text-slate-700 leading-relaxed text-lg">
              Avant de devenir rédacteur spécialisé, j'ai longtemps été impliqué dans le sport local, à la fois comme pratiquant et comme observateur du terrain.
              Plusieurs courses et événements auxquels j'ai participé ont donné lieu à des articles dans Sud Ouest.
              Ces archives témoignent de mon ancrage dans le sport régional et nourrissent aujourd'hui ma manière d'écrire sur le terrain, la performance et le tissu sportif basque.
            </p>
          </div>

          {/* Grid of 3 article cards */}
          <div className="grid md:grid-cols-3 gap-8">
            <SportsArchiveCard 
              title="« Laurenceau s'illustre » – Sud Ouest"
              summary="Article consacré à ma performance sur la Boucle des Plages, classique du BO Athlé, et à la participation des coureurs locaux."
              link="https://www.sudouest.fr/sport/athletisme/laurenceau-s-illustre-9794887.php"
              buttonText="Lire l'article"
            />
            <SportsArchiveCard 
              title="« Julien Laurenceau s'impose en solitaire » – Sud Ouest"
              summary="Compte-rendu de ma victoire sur les 15 km de la Nive, avec mise en contexte de la course et des conditions de course."
              link="https://www.sudouest.fr/sport/athletisme/julien-laurenceau-s-impose-en-solitaire-9005610.php"
              buttonText="Lire l'article"
            />
            <SportsArchiveCard 
              title="Reportage photos – Course sur les bords de mer"
              summary="Galerie de photos de course à pied sur la côte basque, illustrant le terrain, les coureurs et l'ambiance locale."
              link="https://www.sudouest.fr/pyrenees-atlantiques/anglet/en-images-le-premier-trail-d-anglet-remporte-par-julien-laurenceau-4640300.php"
              buttonText="Voir le reportage"
            />
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-24 px-4 container mx-auto max-w-5xl">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl font-bold mb-4">Certifications</h2>
          <p className="text-slate-600">Formation continue en journalisme, analyse de données et IA</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            "Google Data Analytics Capstone",
            "Google Business Intelligence",
            "Visualization for Data Journalism",
            "Principles of Public Relations",
            "Become a Journalist: Report the News!",
            "Writing with Generative AI",
            "AI For Everyone",
            "Work Smarter with Microsoft Excel"
          ].map((cert, i) => (
            <div key={i} className="bg-white p-4 rounded-lg border border-slate-100 flex items-center gap-4 shadow-sm hover:shadow-md transition-all">
              <div className="h-10 w-10 bg-slate-100 rounded flex items-center justify-center flex-shrink-0">
                <img src="/logo.png" className="h-6 w-6 opacity-50" />
              </div>
              <span className="text-xs font-bold text-slate-700 text-left">{cert}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-24 bg-slate-50 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold mb-4">Contact</h2>
            <p className="text-slate-600 text-lg">Discutons de votre projet éditorial</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <Card className="border-slate-200 shadow-lg">
                <CardContent className="p-8">
                  <form className="space-y-5">
                    <div className="grid grid-cols-2 gap-5">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-700">Nom</label>
                        <Input placeholder="Votre nom" className="bg-slate-50 border-slate-200 h-11" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-700">Email</label>
                        <Input type="email" placeholder="votre@email.com" className="bg-slate-50 border-slate-200 h-11" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Sujet</label>
                      <Input placeholder="Proposition de collaboration..." className="bg-slate-50 border-slate-200 h-11" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Message</label>
                      <Textarea placeholder="Bonjour, je souhaiterais échanger à propos de..." className="min-h-[150px] bg-slate-50 border-slate-200 resize-none" />
                    </div>
                    <Button size="lg" className="w-full h-12 text-base">Envoyer le message</Button>
                  </form>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6 flex flex-col">
              <Card className="border-slate-200 shadow-md flex-1">
                <CardContent className="p-8 flex flex-col h-full">
                   <h4 className="font-serif font-bold mb-6 text-lg">Coordonnées</h4>
                   <ul className="space-y-6 text-sm flex-1">
                     <li className="flex items-start gap-4">
                       <div className="bg-primary/10 p-2 rounded-full text-primary">
                         <Mail className="h-4 w-4" />
                       </div>
                       <div>
                         <div className="font-semibold text-slate-900 mb-1">Email</div>
                         <a href="mailto:julien_laurenceau@hotmail.com" className="text-slate-600 hover:text-primary transition-colors">julien_laurenceau@hotmail.com</a>
                       </div>
                     </li>
                     <li className="flex items-start gap-4">
                        <div className="bg-primary/10 p-2 rounded-full text-primary">
                         <Phone className="h-4 w-4" />
                       </div>
                       <div>
                         <div className="font-semibold text-slate-900 mb-1">Téléphone</div>
                         <span className="text-slate-600">06 69 07 02 46</span>
                       </div>
                     </li>
                     <li className="flex items-start gap-4">
                       <div className="bg-primary/10 p-2 rounded-full text-primary">
                         <Linkedin className="h-4 w-4" />
                       </div>
                       <div>
                         <div className="font-semibold text-slate-900 mb-1">LinkedIn</div>
                         <a href="https://www.linkedin.com/in/julien-laurenceau-porte-2b5846394" target="_blank" rel="noreferrer" className="text-slate-600 hover:text-primary transition-colors">
                           Voir mon profil
                         </a>
                       </div>
                     </li>
                   </ul>

                   {/* Digital Signature */}
                   <div className="mt-8 pt-8 border-t border-slate-100 text-center">
                      <img src="/logo.png" className="h-10 w-auto mx-auto mb-3 opacity-80" />
                      <div className="font-serif font-bold text-sm text-slate-900">Julien Laurenceau Porte</div>
                      <div className="text-xs text-slate-500">Rédacteur numérique</div>
                   </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 py-16 text-center text-sm text-slate-400 border-t border-slate-900">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <img src="/logo.png" alt="Logo JLP" className="h-16 w-auto mx-auto invert brightness-0 opacity-90" />
          </div>
          <div className="font-serif text-xl font-bold text-white mb-4">Julien Laurenceau Porte</div>
          <p className="mb-8 max-w-md mx-auto leading-relaxed opacity-70">Rédacteur freelance, spécialiste des chroniques sociales, justice, politique, et culture sportive.</p>
          <div className="flex justify-center gap-6 mb-10">
            <a href="https://www.linkedin.com/in/julien-laurenceau-porte-2b5846394" target="_blank" rel="noreferrer" className="p-3 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-white">
              <Linkedin className="h-5 w-5" />
            </a>
            <a href="mailto:julien_laurenceau@hotmail.com" className="p-3 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-white">
              <Mail className="h-5 w-5" />
            </a>
          </div>
          <div className="border-t border-white/10 pt-8 text-xs opacity-50">
            <p>© 2025 JLP — Chroniques assistées par IA. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ExpertiseCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-all duration-300 group">
      <div className="w-14 h-14 bg-primary rounded-xl flex items-center justify-center mb-6 shadow-md group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="font-serif font-bold text-lg mb-3 text-slate-900">{title}</h3>
      <p className="text-slate-600 text-sm leading-relaxed">{desc}</p>
    </div>
  );
}

function ServiceCard({ title, items }: { title: string, items: string[] }) {
  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-all duration-300">
      <div className="flex items-center gap-3 mb-6">
        <img src="/logo.png" className="h-6 w-auto" />
        <h3 className="font-serif font-bold text-lg text-slate-900 leading-tight">{title}</h3>
      </div>
      <ul className="space-y-3">
        {items.map((item, i) => (
          <li key={i} className="flex items-start gap-3 text-sm text-slate-600">
            <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary/40 flex-shrink-0" />
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

function ChronicleCard({ category, title, excerpt, tags, href }: { category: string, title: string, excerpt: string, tags: string[], href: string }) {
  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-all flex flex-col h-full group hover:-translate-y-1 duration-300">
      <div className="text-xs font-bold text-slate-400 mb-4 uppercase tracking-wider flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-slate-200 group-hover:bg-primary transition-colors"></span>
        {category}
      </div>
      <h3 className="font-serif font-bold text-xl mb-4 group-hover:text-primary transition-colors leading-tight">{title}</h3>
      <p className="text-slate-600 text-sm leading-relaxed mb-8 flex-grow">
        {excerpt}
      </p>
      <div className="flex items-center justify-between mt-auto pt-6 border-t border-slate-50">
        <div className="flex gap-2">
          {tags.map(tag => (
            <span key={tag} className="text-[10px] bg-slate-50 px-2 py-1 rounded text-slate-500 uppercase font-semibold">{tag}</span>
          ))}
        </div>
        <Link href={href}>
          <button className="text-xs font-bold text-primary flex items-center gap-1 hover:underline cursor-pointer uppercase tracking-wide">
            Lire <ArrowRight className="h-3 w-3" />
          </button>
        </Link>
      </div>
    </div>
  );
}

function SportsArchiveCard({ title, summary, link, buttonText }: { title: string, summary: string, link: string, buttonText: string }) {
  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg transition-all flex flex-col h-full group">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-primary/10 p-3 rounded-lg">
          <FileText className="h-6 w-6 text-primary" />
        </div>
        <div className="h-8 w-px bg-slate-200"></div>
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Sud Ouest</span>
      </div>
      
      <h3 className="font-serif font-bold text-xl mb-4 text-slate-900 leading-tight group-hover:text-primary transition-colors">
        {title}
      </h3>
      
      <p className="text-slate-600 text-sm leading-relaxed mb-8 flex-grow">
        {summary}
      </p>
      
      <a href={link} target="_blank" rel="noreferrer noopener" className="mt-auto">
        <Button variant="outline" className="w-full gap-2 border-primary/20 hover:bg-primary hover:text-white transition-colors">
          {buttonText}
          <ArrowRight className="h-4 w-4" />
        </Button>
      </a>
    </div>
  );
}
