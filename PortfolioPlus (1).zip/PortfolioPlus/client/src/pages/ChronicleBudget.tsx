import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChronicleBudget() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Retour au portfolio
            </Button>
          </Link>
          <div className="font-serif font-semibold text-lg">Julien Laurenceau Porte</div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-3xl">
        <article className="prose prose-lg prose-slate mx-auto">
          <div className="mb-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Politique / Économie
            </span>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight">
              Quand « tenir les comptes » devient la faute de solidarité
            </h1>
          </div>

          <div className="space-y-6 text-gray-700 leading-relaxed">
            <p className="font-medium text-xl text-gray-900">
              Pendant que les hôpitaux crèvent et que les soignants s’épuisent, le gouvernement taille dans la Sécu comme on taille une haie trop vivante. Priorité au chiffre, quitte à déchirer ce qu’il reste du tissu social.
            </p>

            <p>
              Mardi, à l’Assemblée nationale, le budget de la Sécurité sociale est passé avant celui de l’État. Une première ? Non. Une priorité ? Certainement pas. Plutôt une opération commando : sabrer dans le social, vite et fort, avant que les cris n’arrivent aux micros.
            </p>

            <p>
              On appelle ça « maîtriser les dépenses ». On pourrait dire « saigner à blanc ». Ce n’est pas un budget, c’est une ordonnance d’austérité. Et le malade, ce n’est pas l’économie : c’est le peuple.
            </p>

            <p>
              Chaque année, on nous ressort la même rengaine : « Il faut revenir à l’équilibre ». Traduction : on va couper là où ça fait mal, mais pas à tout le monde. Pas aux niches fiscales. Pas aux dividendes. Pas aux armées de consultants qui facturent au kilo. Non, on va couper dans les soins, dans les aides, dans les vies.
            </p>

            <p>
              Le citoyen, lui, ne lit pas le budget en ligne. Il le ressent dans sa chair : dans les rendez-vous médicaux annulés, dans les EHPAD qui manquent de bras, dans les remboursements qui s’évaporent. Ce n’est pas une ligne comptable, c’est une fracture nette.
            </p>

            <p>
              Et pendant ce temps, le discours continue : « Il faut être responsable. » Mais responsable de quoi ? De survivre en silence pendant qu’on vous explique que l’État ne peut pas tout ? À croire qu’il ne peut plus rien, sauf protéger les intérêts de ceux qui ne demandent jamais rien — parce qu’ils ont déjà tout.
            </p>

            <p>
              On parle de dette. Mais quelle dette ? Celle des comptes ou celle du cœur ? Parce que pendant qu’on équilibre les colonnes Excel, on déséquilibre la société. Et cette dette-là, sociale, humaine, invisible, elle enfle. Jusqu’à l’explosion.
            </p>

            <p>
              « Tenir les comptes », vraiment ? On ne tient plus rien. Ni la promesse républicaine, ni les services publics, ni la main de ceux qui tombent. On tient juste le cap — vers un désert où la solidarité n’est plus qu’un vieux mot fatigué.
            </p>

            <div className="pt-8 mt-12 border-t border-gray-200 text-center font-serif text-lg">
              JLP
            </div>
          </div>
        </article>
      </main>

      <footer className="bg-gray-50 py-12 border-t">
        <div className="container mx-auto px-4 text-center">
          <h3 className="font-serif text-2xl mb-6">Vous appréciez cette plume ?</h3>
          <div className="flex justify-center gap-4">
            <Link href="/">
              <Button variant="outline">Lire d'autres chroniques</Button>
            </Link>
            <a href="mailto:julien_laurenceau@hotmail.com">
              <Button>Me contacter</Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
