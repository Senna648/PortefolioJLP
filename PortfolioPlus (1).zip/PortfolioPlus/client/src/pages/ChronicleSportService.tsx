import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChronicleSportService() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/chronicles">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Toutes les chroniques
            </Button>
          </Link>
          <div className="font-serif font-semibold text-lg">Julien Laurenceau Porte</div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-3xl">
        <article className="prose prose-lg prose-slate mx-auto">
          <div className="mb-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Sport / Service Public
            </span>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight">
              Sports & service public : une lettre de terrain
            </h1>
            <div className="text-muted-foreground italic">
              Octobre 2025
            </div>
          </div>

          <div className="bg-slate-50 p-8 rounded-lg border border-slate-200 text-slate-800 leading-relaxed font-mono text-sm md:text-base">
            <p className="mb-4 font-bold">Objet : Utilisation des vestiaires de l’AB Campus – Match Top 14 du 18 octobre</p>
            
            <p className="mb-6">Madame, Monsieur,</p>

            <p className="mb-4">
              Dans le cadre du match de Top 14 prévu le samedi 18 octobre au stade Jean-Dauger (environ 20 000 spectateurs attendus), trois rencontres amateurs sont également programmées sur le site de Belascain, sous la supervision de M. Martineau.
            </p>

            <p className="mb-4">
              En raison d’une saturation des vestiaires sur Belascain et sur d’autres sites, le service des sports a envisagé d’utiliser les vestiaires de l’AB Campus. Ce choix soulève toutefois deux problématiques majeures :
            </p>

            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Un risque de sécurité, le site de l’AB Campus étant situé à proximité immédiate du stade Jean-Dauger, déjà fortement mobilisé par le dispositif de sécurité du Top 14 ;</li>
              <li>Une indisponibilité des vestiaires, ceux-ci étant déjà attribués aux ramasseurs de balles pour la même journée.</li>
            </ul>

            <p className="mb-4">
              Lors d’une réunion précédente réunissant les agents de Lauga et de l’AB Campus, ainsi que M. Bruno Camgrand, un accord avait été trouvé concernant la répartition des vestiaires et des emplacements de bus. Cependant, il nous a été indiqué que M. Martineau, avec l’approbation de M. Paytavin, a décidé unilatéralement d’utiliser les installations de l’AB Campus sans concertation préalable avec les agents concernés, précisant qu’il assurerait lui-même la sécurité.
            </p>
            
            <p className="mb-4">
              Nous vous informons que Julien Laurenceau sera de permanence à l’AB Campus le 18 octobre. Il s’engage néanmoins à assurer la gestion des vestiaires conformément aux besoins identifiés.
            </p>
            
            <p className="mb-4">
              Toutefois, avec l’accord de M. Jean-Marie Usandisaga, responsable du site, il est clairement précisé que Julien Laurenceau ne prendra pas en charge la sécurité du portillon ni du portail d’entrée, et que tous deux se dégagent de toute responsabilité en cas d’incident lié à la gestion des flux ou à l’accès au site.
            </p>
            
            <p className="mb-4">
              Cette position vise à garantir la sécurité des personnes et la clarté des responsabilités, dans le respect des procédures hiérarchiques et des consignes de sécurité en vigueur.
            </p>
            
            <p className="mb-6">
              Nous vous remercions de bien vouloir en prendre note et d’assurer une coordination adaptée entre les différents sites concernés.
            </p>

            <p className="mb-8">Cordialement,</p>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <p className="font-bold">Jean-Marie Usandisaga</p>
                <p>Responsable AB Campus</p>
                <p>Ville de Bayonne – Service des Sports</p>
              </div>
              <div>
                <p className="font-bold">Julien Laurenceau</p>
                <p>Agent de la Ville de Bayonne – Service des Sports</p>
              </div>
            </div>
          </div>

          <div className="mt-12 p-6 bg-blue-50 rounded-lg text-blue-900 text-sm">
            <h4 className="font-bold mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-500 rounded-full"></span> Note de l'auteur
            </h4>
            <p>
              Ce document illustre la capacité à rédiger des écrits administratifs sensibles, nécessitant précision, diplomatie et fermeté. Il témoigne d'une compréhension des enjeux de sécurité publique et de responsabilité hiérarchique en contexte de tension logistique.
            </p>
          </div>

          <div className="pt-8 mt-12 border-t border-gray-200 text-center font-serif text-lg">
            JLP
          </div>
        </article>
      </main>

      <footer className="bg-gray-50 py-12 border-t">
        <div className="container mx-auto px-4 text-center">
          <h3 className="font-serif text-2xl mb-6">Vous appréciez cette plume ?</h3>
          <div className="flex justify-center gap-4">
            <Link href="/chronicles">
              <Button variant="outline">Lire d'autres chroniques</Button>
            </Link>
            <a href="mailto:julien_laurenceau@hotmail.com">
              <Button>Me contacter</Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
