import { Link } from "wouter";
import { ArrowLeft, ArrowRight, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function AllChronicles() {
  const [search, setSearch] = useState("");

  const chronicles = [
    {
      title: "Griezmann, l’ombre d’un mentor accusé",
      category: "Justice / Société",
      excerpt: "Bayonne, novembre gris. Un silence dense, presque compact, règne sur les abords du tribunal correctionnel. Les regards se croisent sans oser se fixer... L’affaire dépasse la seule figure de Griezmann : c’est tout un pan du football amateur qui tremble.",
      tags: ["Justice", "Football", "Défense"],
      href: "/chroniques/griezmann",
      date: "Novembre 2025",
      featured: true
    },
    {
      title: "Fin de vie : un pays à la croisée de ses consciences",
      category: "Société / Éthique",
      excerpt: "Il y a des débats que l’on croit éternels tant ils avancent à pas lents, pesants, souvent douloureux. Celui sur la fin de vie est de ceux-là. Ce mois-ci, le Sénat s’apprête à rouvrir la discussion sur une bascule inédite : celle d’un droit à mourir accompagné.",
      tags: ["Société", "Éthique", "Politique"],
      href: "/chroniques/fin-de-vie",
      date: "Octobre 2025",
      featured: false
    },
    {
      title: "Quand « tenir les comptes » devient la faute de solidarité",
      category: "Politique / Économie",
      excerpt: "Pendant que les hôpitaux crèvent et que les soignants s’épuisent, le gouvernement taille dans la Sécu comme on taille une haie trop vivante. Priorité au chiffre, quitte à déchirer ce qu’il reste du tissu social.",
      tags: ["Budget", "Santé", "Politique"],
      href: "/chroniques/budget",
      date: "Novembre 2025",
      featured: false
    },
    {
      title: "Île d’Oléron : la violence des invisibles",
      category: "Société / Faits divers",
      excerpt: "Un mercredi de novembre sur l’île d’Oléron, le calme a cédé place à l’absurde. Trente-cinq minutes durant, un homme seul au volant de sa voiture a volontairement percuté cinq personnes. Une fracture silencieuse.",
      tags: ["Société", "Faits divers", "Analyse"],
      href: "/chroniques/oleron",
      date: "Novembre 2025",
      featured: false
    },
    {
      title: "La Colère Tiède",
      category: "Société / Terrain",
      excerpt: "Bayonne. Un matin d’automne. Le ciel hésite entre la pluie et l’attente. Trois cents retraités marchent. Une colère basse qui ne claque pas, mais qui couve. Une colère tiède — et c’est peut-être ce qu’il y a de plus dangereux.",
      tags: ["Société", "Retraites", "Bayonne"],
      href: "/chroniques/colere-tiede",
      date: "Octobre 2025",
      featured: false
    },
    {
      title: "Les otages revenus du silence",
      category: "International / Diplomatie",
      excerpt: "Quand leurs pieds ont touché le sol de Villacoublay, un frisson a traversé l’assemblée. Cécile Kohler et Jacques Paris sont rentrés. Ils étaient partis en touristes. Ils reviennent en symboles d’une diplomatie obstinée.",
      tags: ["International", "Diplomatie", "Iran"],
      href: "/chroniques/otages",
      date: "Novembre 2025",
      featured: false
    },
    {
      title: "Sports & service public : une lettre de terrain",
      category: "Sport / Service Public",
      excerpt: "Document professionnel : gestion d'une situation de crise logistique et sécuritaire lors d'un match de Top 14. Exemple de rédaction administrative sensible nécessitant précision et fermeté.",
      tags: ["Administration", "Sport", "Sécurité"],
      href: "/chroniques/sport-service",
      date: "Octobre 2025",
      featured: false
    }
  ];

  const filteredChronicles = chronicles.filter(c => 
    c.title.toLowerCase().includes(search.toLowerCase()) || 
    c.tags.some(tag => tag.toLowerCase().includes(search.toLowerCase())) ||
    c.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="gap-2 font-serif">
              <ArrowLeft className="h-4 w-4" />
              Retour au portfolio
            </Button>
          </Link>
          <div className="flex items-center gap-2">
             <img src="/logo.png" alt="Logo JLP" className="h-8 w-auto object-contain" />
             <div className="font-serif font-semibold text-lg">JLP</div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-5xl">
        <div className="mb-12 text-center">
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            Toutes les chroniques
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10">
            L'intégralité de mes textes : analyses sociales, récits judiciaires, décryptages politiques et observations de terrain.
          </p>
          
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input 
              placeholder="Rechercher une chronique..." 
              className="pl-10 h-12 bg-white"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="grid gap-8">
          {filteredChronicles.map((chronicle, index) => (
            <Link href={chronicle.href} key={index}>
              <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:shadow-lg transition-all cursor-pointer group hover:-translate-x-1 flex flex-col md:flex-row gap-8 items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-1 rounded">
                      {chronicle.category}
                    </span>
                    <span className="text-xs text-slate-400">
                      {chronicle.date}
                    </span>
                  </div>
                  <h3 className="font-serif text-2xl font-bold mb-3 group-hover:text-primary transition-colors">
                    {chronicle.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed mb-6">
                    {chronicle.excerpt}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {chronicle.tags.map(tag => (
                      <span key={tag} className="text-[10px] border border-slate-200 px-2 py-1 rounded text-slate-500 uppercase font-medium">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center justify-center self-center md:self-start mt-4 md:mt-0">
                  <div className="h-10 w-10 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                    <ArrowRight className="h-5 w-5" />
                  </div>
                </div>
              </div>
            </Link>
          ))}

          {filteredChronicles.length === 0 && (
            <div className="text-center py-20 bg-slate-50 rounded-xl border border-dashed border-slate-300">
              <p className="text-slate-500">Aucune chronique ne correspond à votre recherche.</p>
              <Button variant="link" onClick={() => setSearch("")}>Tout effacer</Button>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-slate-950 py-12 text-center text-sm text-slate-400 border-t border-slate-900 mt-20">
        <div className="container mx-auto px-4">
          <p>© 2025 JLP — Chroniques assistées par IA. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
}
